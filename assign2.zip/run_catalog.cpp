/****************************************************** 
** Program: run_catalog.cpp 
** Author: Hailey Mendenhall
** Date: 2/08/2024 
** Description: This program has the main function that uses catalog.cpp and runs all the functions within that to allow user to manipulate and access array.
and then allows the yser to do things with that array such as search for a song or print all songs. 
** Input: User's text file with playlist and song information, users age
** Output: Information about playlist array, errors if inputs are not valid, options for what user can do with array
******************************************************/ 

#include "catalog.h"

using namespace std;

int main(){	
	// these next lines create the ifstream and run the function that error checks it. 
	ifstream fin;
	if (get_file(fin) == 1){
		fin.close();
		return 1;
	} 

	// runs error checking function for age 
	int age = check_age();

	// these next few lines run the functions that actually declare and initialize array
	int num_playlists;
	fin >> num_playlists;
	Playlist * playlist_arr = create_playlists(num_playlists);
	init_array(playlist_arr, num_playlists, fin);	

	// creates ofstream
	ofstream fout;	

	// this next section is really the core of the program
	//initializes choice, runs function	telling user what they can do and getting input for what they want to do
	//then calls function that runs the correct next function based on the decision the user made	
	int choice;
	do{
		choice = ask_user_for_option(playlist_arr, num_playlists, fout);
		if (choice == 5){
        	cout << "Goodbye! Thanks for using my tune finder program :)" << endl;
			delete_info(playlist_arr, num_playlists);
        	return 0;
    	}	
		int screen_or_file = where_to_display(choice, playlist_arr, num_playlists, age);
		run_correct_program (choice, screen_or_file, playlist_arr, num_playlists, fout);			
	}while (!(choice == 5));

	//closes input and output streams
	fin.close();
	fout.close();

	//frees memory
	delete_info(playlist_arr, num_playlists);
	return 0;
}