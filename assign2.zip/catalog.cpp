/****************************************************** 
** Program: catalog.cpp 
** Author: Hailey Mendenhall
** Date: 2/08/2024 
** Description: This program takes user input, makes an array of playlists made up of songs with this input, 
and then allows the yser to do things with that array such as search for a song or print all songs. 
** Input: User's text file with playlist and song information, users age
** Output:Information about playlist array, errors if inputs are not valid, options for what user can do with array
******************************************************/ 

#include "catalog.h"

using namespace std;

int get_file(ifstream & fin){
    string file_name;
	cout << "Please enter your playlist information text file name: " ;
	cin >> file_name;
    fin.open(file_name, ios::in);
    // Check if file is valid
    if(!fin.is_open()){
        cout << "Sorry, that file name is not valid." << endl;
        return 1;
    }else {
        return 0; 
    }
}

int check_age (){
    string age;
    //creates boolean for whether good age has been found or not
    bool valid_age = true;
    do {
        valid_age = true; 
        //takes in user input for age       
	    cout << "Please enter your age: ";
	    cin >> age;   
        //makes sure age is not zero     
        if (age.length() == 1){
            int num = age[0];
            if (num == 48){
                cout << "That is not a valid age. Please try again. " << endl;
                valid_age = false;
            } 
        }
        //makes sure age is a number
        for (int i = 0; i < age.length(); i++){
            int num = age[i];
            if (num < 48 || num > 57){
                
                valid_age = false;  
            }
        }
        if (!valid_age){
            cout << "That is not a valid age. Please try again. " << endl;
        }        
    } while (!valid_age);
    int final_age = stoi(age);
    return final_age;
}

Playlist* create_playlists(int size){
    //dynmaically allocates playlist array
    Playlist* playlist_arr = new Playlist [size];  
    return playlist_arr;
}

void init_array(Playlist* playlist_arr, int num_playlists, ifstream& fin){
    //calls populate one list and populate one song correct number of times 
    //depending on how many there are
    for (int i = 0; i < num_playlists; i++){
		populate_one_list(playlist_arr, i, fin);
		for (int j = 0; j < playlist_arr[i].num_song; j++){
			populate_one_song(playlist_arr[i].s, j, fin);
		}
	}
}

void populate_one_list(Playlist* playlist_arr, int index, ifstream & fin){
    //fills in playlist struct for one index of playlist array
    fin >> playlist_arr[index].name;
    fin >> playlist_arr[index].num_song; 
    playlist_arr[index].s = create_songs(playlist_arr[index].num_song);    
}

Song * create_songs(int size){
    //dynamically allocates song array
    Song* song_arr = new Song [size];
    return song_arr;
}

void populate_one_song(Song* s, int index, ifstream & fin){
    //fills in song struct for one index of song array within playlist
    fin >> s[index].name;
    fin >> s[index].artist;
    fin >> s[index].year_release;
    fin >> s[index].length;
    fin >> s[index].genre;
    fin >> s[index].res;
}

int ask_user_for_option(Playlist* playlist_arr, int num_playlists, ofstream& fout){
    //tells user what they can do and has them input what one to run
    cout << "What option would you like to choose? " << endl;
    cout << "1. Display all songs" << endl;
    cout << "2. Search for a song to play" << endl;
    cout << "3. Search songs by genre" << endl;
    cout << "4. Display length of all playlists" << endl;
    cout << "5. Quit" << endl;
    int choice;
    cout << "Your choice: ";
    cin >> choice;    
    return choice;
}

int where_to_display (int choice, Playlist* playlist_arr, int num_playlists, int age){
    //unless user option is one, asks if they want info to screen or file
    int screen_or_file;
    if (choice == 1){
        if (age < 20){
            all_not_restricted_songs(playlist_arr, num_playlists);            
        }else {
            all_songs(playlist_arr, num_playlists);
        }
    } else {        
        cout << "How would you like that information displayed? " << endl;
        cout << "Print to screen (Press 1)" << endl;
        cout << "Print to file (Press 2)" << endl;
        cout << "Your Choice: " ;
        cin >> screen_or_file;
    }
    return screen_or_file;    
}

void run_correct_program(int choice, int screen_or_file, Playlist* playlist_arr, int num_playlists, ofstream& fout){    
    if (choice == 2){
        find_song(playlist_arr, num_playlists, screen_or_file, fout);
    }else if (choice == 3){
        if (screen_or_file == 1){
            print_genre(playlist_arr, num_playlists);
        }else if (screen_or_file == 2){
            genre_to_file(playlist_arr, num_playlists, fout);
        }        
    }else if (choice == 4){
        if (screen_or_file == 1){
            length_of_playlists_screen(playlist_arr, num_playlists);
        }else if (screen_or_file == 2){
            length_of_playlists_file(playlist_arr, num_playlists, fout);
        }
    }   
}

void all_songs(Playlist* playlist_arr, int num_playlists){
    for (int h = 0; h < num_playlists; h++){
        cout << "-------------------------------" << endl;
        cout << "Playlist: " << playlist_arr[h].name << endl;
        for (int k = 0; k < playlist_arr[h].num_song; k++){
            cout << "-------------------------------" << endl;
            cout << "Name: " << playlist_arr[h].s[k].name << endl;
            cout << "Artist: " << playlist_arr[h].s[k].artist << endl;
            cout << "Year Released: " << playlist_arr[h].s[k].year_release << endl;
            cout << "Length: " << playlist_arr[h].s[k].length << endl;
            cout << "Genre: " << playlist_arr[h].s[k].genre << endl;
            cout << "Restriction: " << playlist_arr[h].s[k].res << endl;
            cout << "-------------------------------" << endl;
        }   
    }
}

void all_not_restricted_songs(Playlist* playlist_arr, int num_playlists){
    for (int h = 0; h < num_playlists; h++){
        cout << "-------------------------------" << endl;
        cout << "Playlist: " << playlist_arr[h].name << endl;
        for (int k = 0; k < playlist_arr[h].num_song; k++){
            if (playlist_arr[h].s[k].res == "None"){
                cout << "-------------------------------" << endl;
                cout << "Name: " << playlist_arr[h].s[k].name << endl;
                cout << "Artist: " << playlist_arr[h].s[k].artist << endl;
                cout << "Year Released: " << playlist_arr[h].s[k].year_release << endl;
                cout << "Length: " << playlist_arr[h].s[k].length << endl;
                cout << "Genre: " << playlist_arr[h].s[k].genre << endl;
                cout << "Restriction: " << playlist_arr[h].s[k].res << endl;
                cout << "-------------------------------" << endl;
            }
        }   
    }
}

/*void all_songs_to_file(Playlist* playlist_arr, int num_playlists, ofstream& fout){
    for (int h = 0; h < num_playlists; h++){
        fout << "-------------------------------" << endl;
        fout << "Playlist: " << playlist_arr[h].name << endl;
        for (int k = 0; k < playlist_arr[h].num_song; k++){
            fout << "-------------------------------" << endl;
            fout << "Name: " << playlist_arr[h].s[k].name << endl;
            fout << "Artist: " << playlist_arr[h].s[k].artist << endl;
            fout << "Year Released: " << playlist_arr[h].s[k].year_release << endl;
            fout << "Length: " << playlist_arr[h].s[k].length << endl;
            fout << "Genre: " << playlist_arr[h].s[k].genre << endl;
            fout << "Restriction: " << playlist_arr[h].s[k].res << endl;
            fout << "-------------------------------" << endl;
        }   
    }
    cout << "Requested information has been appended to file!" << endl;
}

void all_not_restricted_songs_to_file(Playlist* playlist_arr, int num_playlists, ofstream& fout){
    for (int h = 0; h < num_playlists; h++){
        fout << "-------------------------------" << endl;
        fout << "Playlist: " << playlist_arr[h].name << endl;
        for (int k = 0; k < playlist_arr[h].num_song; k++){
            if (playlist_arr[h].s[k].res = "None"){
                fout << "-------------------------------" << endl;
                fout << "Name: " << playlist_arr[h].s[k].name << endl;
                fout << "Artist: " << playlist_arr[h].s[k].artist << endl;
                fout << "Year Released: " << playlist_arr[h].s[k].year_release << endl;
                fout << "Length: " << playlist_arr[h].s[k].length << endl;
                fout << "Genre: " << playlist_arr[h].s[k].genre << endl;
                fout << "Restriction: " << playlist_arr[h].s[k].res << endl;
                fout << "-------------------------------" << endl;
            }
        }
    }  
    cout << "Requested information has been appended to file!" << endl;
}*/

int find_song (Playlist* playlist_arr, int num_playlists, int file_or_print, ofstream& fout){
	string song_search;
	cout << "What song would you like to search for? ";
	cin >> song_search;
	for (int i = 0; i < num_playlists; i++){
        for (int f = 0; f < playlist_arr[f].num_song; f++){
		    if (song_search == playlist_arr[i].s[f].name){
			    if (file_or_print == 1){
                    print_specific_song(playlist_arr[i].s[f]);
                    return 0;
                }else {
                    specific_song_to_file(playlist_arr[i].s[f], fout);
                    return 0;
                }
		    }
        }    
    }
	return -1;
}

void print_specific_song(Song s){
    cout << "-------------------------------" << endl;
    cout << "Name: " << s.name << endl;
    cout << "Artist: " << s.artist << endl;
    cout << "Year Released: " << s.year_release << endl;
    cout << "Length: " << s.length << endl;
    cout << "Genre: " << s.genre << endl;
    cout << "Restriction: " << s.res << endl;
    cout << "-------------------------------" << endl;
}

void specific_song_to_file(Song s, ofstream& fout){
    string file_name;
    cout << "Please enter the file name you would like the information appended to: ";
    cin >> file_name;    
	fout.open(file_name, ios::app);
    fout << "-------------------------------" << endl;
    fout << "Name: " << s.name << endl;
    fout << "Artist: " << s.artist << endl;
    fout << "Year Released: " << s.year_release << endl;
    fout << "Length: " << s.length << endl;
    fout << "Genre: " << s.genre << endl;
    fout << "Restriction: " << s.res << endl;
    fout << "-------------------------------" << endl;
    cout << "Requested information has been appended to file!" << endl;
    fout.close();
}

void print_genre(Playlist* playlist_arr, int num_playlists){
    string genre_search;
    cout << "What genre would you like to search for? ";
    cin >> genre_search;
    for (int h = 0; h < num_playlists; h++){        
        for (int k = 0; k < playlist_arr[h].num_song; k++){
            if (playlist_arr[h].s[k].genre == genre_search){
                cout << "-------------------------------" << endl;
                cout << "Name: " << playlist_arr[h].s[k].name << endl;
                cout << "Artist: " << playlist_arr[h].s[k].artist << endl;
                cout << "Year Released: " << playlist_arr[h].s[k].year_release << endl;
                cout << "Length: " << playlist_arr[h].s[k].length << endl;
                cout << "Genre: " << playlist_arr[h].s[k].genre << endl;
                cout << "Restriction: " << playlist_arr[h].s[k].res << endl;
                cout << "-------------------------------" << endl;
            }
        }   
    }
}

void genre_to_file (Playlist* playlist_arr, int num_playlists, ofstream& fout){    
    string file_name;
    cout << "Please enter the file name you would like the information appended to: ";
    cin >> file_name;  
	fout.open(file_name, ios::app);  
    string genre_search;
    cout << "What genre would you like to search for? ";
    cin >> genre_search;
    for (int h = 0; h < num_playlists; h++){        
        for (int k = 0; k < playlist_arr[h].num_song; k++){
            if (playlist_arr[h].s[k].genre == genre_search){
                fout << "-------------------------------" << endl;
                fout << "Name: " << playlist_arr[h].s[k].name << endl;
                fout << "Artist: " << playlist_arr[h].s[k].artist << endl;
                fout << "Year Released: " << playlist_arr[h].s[k].year_release << endl;
                fout << "Length: " << playlist_arr[h].s[k].length << endl;
                fout << "Genre: " << playlist_arr[h].s[k].genre << endl;
                fout << "Restriction: " << playlist_arr[h].s[k].res << endl;
                fout << "-------------------------------" << endl;
            }
        }   
    }
    cout << "Requested information has been appended to file!" << endl;    
    fout.close();
}

void length_of_playlists_screen(Playlist* playlist_arr, int num_playlists){
    cout << "Here are the lengths of the playlists: " << endl;
    for (int i = 0; i < num_playlists; i++){
        float length_playlist = 0;
        for (int j = 0; j < playlist_arr[i].num_song; j++){
            length_playlist += playlist_arr[i].s[j].length;
        }        
        cout << playlist_arr[i].name << ": " << length_playlist << endl;
        cout << endl;
    }
}

void length_of_playlists_file(Playlist* playlist_arr, int num_playlists, ofstream& fout){
    string file_name;
    cout << "Please enter the file name you would like the information appended to: ";
    cin >> file_name;  
	fout.open(file_name, ios::app);
    fout << "Here are the lengths of the playlists: " << endl;
    fout << endl;
    for (int i = 0; i < num_playlists; i++){
        float length_playlist = 0;
        for (int j = 0; j < playlist_arr[i].num_song; j++){
            length_playlist += playlist_arr[i].s[j].length;
        }        
        fout << playlist_arr[i].name << ": " << length_playlist << endl;
        fout<< endl;
    }
    cout << "Requested information has been appended to file!" << endl;  
    fout.close();  
}

void delete_info(Playlist* playlist_arr, int num_playlists){
    for (int i = 0; i < num_playlists; i++){        
        delete [] playlist_arr[i].s;
        playlist_arr[i].s = nullptr;
    }
    delete [] playlist_arr;
    playlist_arr = nullptr;
}

