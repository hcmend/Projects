#include <iostream>
#include <fstream>

using namespace std;

//a struct to hold info of a Playlist
struct Playlist {
	string name;        //name of the playlist, one word
	int num_song;       //number of songs in the playlist
	struct Song *s;     //an array that holds all songs in the playlist
	float total_len;    //total length of the playlist
};

//a struct to hold info of a Song
struct Song {
	string name;		//name of the song, one word
	string artist;		//name of the artist, one word
	int year_release;	//the year of release
	float length;		//length of the song
	string genre;		//genre of the song, one word
	string res;			//"E" or "none" for restriction level
};

/**************************************************
 * Name: get_file()
 * Description: This function take in user input for the name of the file with all playlist and sogn information
 * Parameters: ifstream & - the file input stream that does not have an opened file yet
 * Pre-conditions: None
 * Post-conditions: a correct file name is opened and int is returned to tell program if file was valid or not
 ***********************************************/
int get_file(ifstream &);

/**************************************************
 * Name: check_age()
 * Description: This function will error check the user input for their age
 * Parameters: none
 * Pre-conditions: none
 * Post-conditions: continues to ask for age until valid one is entered and returns that
 ***********************************************/
int check_age ();

/**************************************************
 * Name: create_playlists()
 * Description: This function will dynamically allocate
				an array of playlists (of the requested size)
 * Parameters: int - size of the array
 * Pre-conditions: none
 * Post-conditions: a Playlist array of requested size is created and return
 ***********************************************/
Playlist* create_playlists(int);

/**************************************************
 * Name: init_array()
 * Description: This function will initialize the playlist array, filling all of its components as well as the components of its nested song array. 
 * Parameters: 	Playlist* - declared playlist array,
 				int - number of playlists
				ifstream& - opened input file
 * Pre-conditions: valud input file has been opened, playlist array has been declared and allocated, num_playlists has been taken correctly.
 * Post-conditions: the playlist array has been correct filled in with information from user inputted file
 ***********************************************/
void init_array(Playlist* playlist_arr, int num_playlists, ifstream& fin);

/**************************************************
 * Name: populate_one_list()
 * Description: This function will fill a single playlist struct with information that is read in from the file
 * Parameters:  Playlist* - pointer to the Playlist array
				int - index of the Playlist in the array to be filled 
				ifstream& - input file to get the Playlist information
 * Pre-conditions: Playlist array has been allocated; 
				 provided index is less than the array size
 * Post-conditions: a Playlist at provided index is populated
 ***********************************************/
void populate_one_list(Playlist*, int, ifstream &); 


/**************************************************
 * Name: create_songs()
 * Description: This function will dynamically allocate
				an array of songs (of the requested size)
 * Parameters: int - size of the array
 * Pre-conditions: none
 * Post-conditions: a Song array of requested size is created and return
 ***********************************************/
Song* create_songs(int);


/**************************************************
 * Name: populate_one_song()
 * Description: This function will fill a single song struct 
				with information that is read in from the file
 * Parameters:  Song* - pointer to the Song array
				int - index of the Song in the array to be filled 
				ifstream& - input file to get the Song information
 * Pre-conditions: Song array has been allocated; 
				 provided index is less than the array size
 * Post-conditions: a Song at provided index is populated
 ***********************************************/
void populate_one_song(Song*, int, ifstream &); 

/**************************************************
 * Name: ask_user_for_option()
 * Description: This function will ask the user what they want to do with the playlist array
 * Parameters: Playlist* - declared and initialized playlist array
 				int - number of playlists
				ofstream& - file output stream without an opened file
 * Pre-conditions: playlist array has been made correctly, num_playlists is correct, file output stream has been declared
 * Post-conditions: gets input from user and returns the number of option they have decided to do
 ***********************************************/
int ask_user_for_option(Playlist* playlist_arr, int num_playlists, ofstream& fout);

/**************************************************
 * Name: where_to_display()
 * Description: This function takes in user input, asking whether they want to print to screen or to a file of their choice
 * Parameters:  int - option they chose
 				Playlist* - declared and initialized playlist array
				int - number of playlists
				ofstream& - file output stream w/o open file
 * Pre-conditions: playlist_arr has been made correctly, choice has been declared, num_playlists is correct, age is a positive integer
 * Post-conditions: gets user to enter 1 for screen or 2 for file and returns correct one
 ***********************************************/
int where_to_display (int choice, Playlist* playlist_arr, int num_playlists, int age);

/**************************************************
 * Name: run_correct_program()
 * Description: This function will run another function based on what option the user chose and whether they want to print to screen or file
 * Parameters:  int - option user chose
  				int - 1 for screen or 2 for file
 				Playlist* - declared and initialized playlist array
				int - number of playlists
				ofstream& - file output stream w/o open file * 		
 * Pre-conditions: choice and screen_or_file have been taken from user, playlist array is set up right, num_playlists is an int, fout has been declared
 * Post-conditions: another function is called correctly
 ***********************************************/
void run_correct_program(int choice, int screen_or_file, Playlist* playlist_arr, int num_playlists, ofstream& fout);

/**************************************************
 * Name: all_songs()
 * Description: This function will print all songs to screen, regardless of restriction since user has been determined of age
 * Parameters:  Playlist* - declared and initialized playlist array
				int - number of playlists				 		
 * Pre-conditions: playlist array is set up right, num_playlists is an int
 * Post-conditions: songs have been outputted to screen for user to see
 ***********************************************/
void all_songs(Playlist* , int);

/**************************************************
 * Name: all_not_restricted_songs()
 * Description: This function will print all songs with no restriction to screen since user has been determined to be 19 or younger
 * Parameters:  Playlist* - declared and initialized playlist array
				int - number of playlists				 		
 * Pre-conditions: playlist array is set up right, num_playlists is an int
 * Post-conditions: songs have been outputted to screen for user to see
 ***********************************************/
void all_not_restricted_songs(Playlist* playlist_arr, int num_playlists);

/**************************************************
 * Name: run_correct_program()
 * Description: This function will ask the user the title of the song they want to search for and then call another function, printing it to screen or file
 * Parameters:  Playlist* - declared and initialized playlist array
				int - number of playlists
				int - 1 for screen or 2 for file
				ofstream& - file output stream w/o open file * 		
 * Pre-conditions: screen_or_file has been taken from user, playlist array is set up right, num_playlists is an int, fout has been declared
 * Post-conditions: song user inputted is correctly passes into another function
 ***********************************************/
int find_song (Playlist* playlist_arr, int num_playlists, int file_or_print, ofstream& fout);

/**************************************************
 * Name: print_specific_song()
 * Description: This function will print the information of the song user searched for to screen
 * Parameters:  Song - variable song that user wanted to search for 		
 * Pre-conditions: that song was set up correctly within the playlist array
 * Post-conditions: song is correctly printed to screen
 ***********************************************/
void print_specific_song(Song s);

/**************************************************
 * Name: specific_song_to_file()
 * Description: This function will print the information of the song user searched for to screen
 * Parameters:  Song - variable song that user wanted to search for 
 				ofstream - file output stream w/o open file		
 * Pre-conditions: that song was set up correctly within the playlist array
 * Post-conditions: song is correctly printed to screen
 ***********************************************/
void specific_song_to_file(Song s, ofstream& fout);

/**************************************************
 * Name: print_genre()
 * Description: This function will ask the user what genre of songs they want to print and then print all of those to screen
 * Parameters:  Playlist* - declared and initialized playlist array
				int - number of playlists						
 * Pre-conditions: playlist array is set up right, num_playlists is an int and correct
 * Post-conditions: correct songs are outputted
 ***********************************************/
void print_genre(Playlist* playlist_arr, int num_playlists);

/**************************************************
 * Name: genre_to_file()
 * Description: This function will ask the user what genre of songs they want to print and then print all of those to file
 * Parameters:  Playlist* - declared and initialized playlist array
				int - number of playlists	
				ofstream - file output stream w/o open file					
 * Pre-conditions: playlist array is set up right, num_playlists is an int and correct, file output stream has been declared
 * Post-conditions: correct songs are outputted
 ***********************************************/
void genre_to_file (Playlist* playlist_arr, int num_playlists, ofstream& fout);

/**************************************************
 * Name: length_of_playlists_screen()
 * Description: This function will print the length of all playlists to the screen
 * Parameters:  Playlist* - declared and initialized playlist array
				int - number of playlists						
 * Pre-conditions: playlist array is set up right, num_playlists is an int and correct
 * Post-conditions: correct lengths are outputted
 ***********************************************/
void length_of_playlists_screen(Playlist* playlist_arr, int num_playlists);

/**************************************************
 * Name: length_of_playlists_file()
 * Description: This function will print the length of all playlists to the file
 * Parameters:  Playlist* - declared and initialized playlist array
				int - number of playlists	
				ofstream - file output stream w/o open file					
 * Pre-conditions: playlist array is set up right, num_playlists is an int and correct, file output stream has been declared
 * Post-conditions: correct lengths are outputted  
 ***********************************************/
void length_of_playlists_file(Playlist* playlist_arr, int num_playlists, ofstream& fout);

/**************************************************
 * Name: delete_info()
 * Description: This function will  delete all the memory that was dynamically allocated
 * Parameters: Playlist* - the Playlist array
 * Pre-conditions: the provided Playlist array hasn't been freed yet
 * Post-conditions: the Playlist array, with all Songs inside, is freed
 ***********************************************/
void delete_info(Playlist*, int);
