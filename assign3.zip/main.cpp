/****************************************************** 
** Program: flight_manager.cpp 
** Author: Hailey Mendenhall
** Date: 2/20/2024 
** Description: This program is a simulation for the user of being a flight manager. They can control the airports and flights, adding flights, cancelling flights, and sending them to their destination. 
** Input: What choice they want which decides how they will interact with the airport and flight arrays. 
** Output: Airport information, flight information, pilot information
******************************************************/ 



#include <iostream>
#include "manager.h"

using namespace std;

int main(){
	Manager m; //creates a manager object
	m.run(); //calls run function of manager which handles all other function calling
	//Flight f1(10);
	//Flight f2(5);
	//f1 = f2;	
	//Flight f3 = f1;
	return 0;
}