#ifndef MANAGER_H
#define MANAGER_H 

#include "airport.h"
#include <iostream>
#include <fstream>

using namespace std;

class Manager
{
private:
	int num_airports;	//number of airports
	Airport* a_arr;		//airport array

public:
	//manager only needs default constructor and destructor because we are never copying info from manager to another manager object. we only have one manager throughout program
	Manager();
	~Manager();

	/*********************************************************************  
	** Function: populate()
	** Description: this starts the chain of population getting airports to populate themselves and then tell their flights to populate themselves
	** Parameters:  ifstream&: file input that has been opened 
	** Pre-Conditions: text file has been opened correctly
	** Post-Conditions:  information has been populated correctly
	*********************************************************************/
	void populate(ifstream& fin);

	/*********************************************************************  
	** Function: init()
	** Description: initializes the manager with its information, tells it to populate, and opens text file
	** Parameters:  none
	** Pre-Conditions: none
	** Post-Conditions:  none
	*********************************************************************/
	int init();

	/*********************************************************************  
	** Function: print_menu()
	** Description: prints all the options that the user can do to the screen
	** Parameters:  none
	** Pre-Conditions: none
	** Post-Conditions:  none
	*********************************************************************/
	void print_menu();

	/*********************************************************************  
	** Function: get_menu_choice()
	** Description: this gets the option that the user wants to do
	** Parameters:  none
	** Pre-Conditions: none
	** Post-Conditions:  user has entered an int for their option
	*********************************************************************/
	int get_menu_choice();
	
	/*********************************************************************  
	** Function: print_all()
	** Description: this starts the chain of printing, getting all airports to print themselves and then tall their flights to print themselves
	** Parameters:  none
	** Pre-Conditions: everything has been populated correctly
	** Post-Conditions:  none
	*********************************************************************/
	void print_all();

	/*********************************************************************  
	** Function: check_flight_control()
	** Description: this gets the flight number the user wants to search for and then calls each airport to look for that flight
	** Parameters:  none
	** Pre-Conditions: all airports have been populated correctly
	** Post-Conditions:  none
	*********************************************************************/
	void check_flight_control();

	/*********************************************************************  
	** Function: add_flight_control()
	** Description: this gets all information of flight that user wants to add and what airport to add it to and then calls that airport to add it to themself
	** Parameters:  none
	** Pre-Conditions: airports have been populated correctly
	** Post-Conditions:  flight was added to correct airport and correct spot in their array
	*********************************************************************/
	void add_flight_control();

	/*********************************************************************  
	** Function: cancel_flight_control()
	** Description: this gets the flight that the user wants to cancel and then calls the airport it is in to cancel that flight from themself
	** Parameters:  none
	** Pre-Conditions: airports and flights all populated correctly
	** Post-Conditions:  right fligth was cancelled and all those after it in array were shifted down
	*********************************************************************/
	void cancel_flight_control();

	/*********************************************************************  
	** Function: take_off_control()
	** Description: this simulates taking off a flight, removing it from its current airport and adding it to its destination
	** Parameters:  none
	** Pre-Conditions: airports and flights all populated correctly
	** Post-Conditions:  right flight was moved and its current location has been set to match its destination
	*********************************************************************/
	void take_off_control();

	/*********************************************************************  
	** Function: stats_control()
	** Description: this prints all the information about the airport including its name, capacity, and number of flights that has it as its destination
	** Parameters:  none
	** Pre-Conditions: airports and flights all populated correctly
	** Post-Conditions:  none
	*********************************************************************/
	void stats_control();

	/*********************************************************************  
	** Function: update_text_file()
	** Description: this updates the text file user inputted will all the new information based on what flights they added, removed, and had take off
	** Parameters:  none
	** Pre-Conditions: airports and flights all populated correctly
	** Post-Conditions:  none
	*********************************************************************/
	void update_text_file();
	
	/*********************************************************************  
	** Function: run()
	** Description: this runs the right program based on what option the user chose
	** Parameters:  none
	** Pre-Conditions: user chose an option to do
	** Post-Conditions:  none
	*********************************************************************/
	void run();
};
#endif