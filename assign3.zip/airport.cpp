#include "airport.h"

using namespace std;

Airport::Airport() {
	//blank because will get filled with file information
}


Airport::~Airport() {
	//cout << "destructor called" << endl;
	//frees flight array within airport
	if (this -> f_arr != NULL){
		delete [] this-> f_arr;
		this -> f_arr = NULL;
	}
}


void Airport::populate_airport(ifstream& fin){
	//prints all airport info
	fin >> this -> name;
	fin >> this -> num_flights;
	fin >> this -> cap;
	this -> f_arr = new Flight [cap];
	//calls all flights within airport to ppopulate their info
	for(int i = 0; i < this -> num_flights; i++){
		f_arr[i].populate_flight(fin);
	}
	return; 
}

//sees if flight user searched for is there
int Airport :: check_for_flight (string flight_search){	
	for (int m = 0; m < this-> num_flights; m++){
		if (f_arr[m].get_flight_num() == flight_search){ // comparing flight number to one user entered
			cout << "Flight has been found!" << endl;
			f_arr[m].print_flight();
			return 1; //inside if so it returns 1 if flight was found		
		}
	}
	
	return 2; // returns 2 if flight was not found
}

void Airport::add_a_flight(Flight& p){
	this -> f_arr[(this->num_flights)] = p;  //adds flight to end of flight array for this airport
	string pilot_name; 
	f_arr[(this->num_flights)].fill_pilots();		
	this->num_flights ++;	//updates number of flights at airport
	cout << "Your flight has been added to airport " << this-> name << "!" << endl;
	return; 
}

//adds flight that has taken off from another airport
void Airport::add_a_complete_flight(Flight& p){
	this -> f_arr[(this->num_flights)] = p;	//adds flight to end of flight array
	this -> f_arr[num_flights].set_curr_loc(this -> name); //updates current location to new airport
	this -> num_flights++; //updates number of flights at airport
	return;
}

//getters
string Airport:: get_name () const{
	return this -> name; 
}

int Airport :: get_num_flights () const {
	return this->num_flights; 
}

int Airport :: get_cap () const {
	return this->cap;
}

//removes flight from specific airport and shifts array accordingly
Flight Airport::remove_a_flight(int idx){
	Flight f = f_arr[idx];	
	for (int i = idx; i < this-> num_flights - 1; i++){
		f_arr[i] = f_arr[i+1]; //shifts all flights above index down one
	}		
	this -> num_flights --;	//updates number of flights
	return f;
}

int Airport::check_if_at_destination(int idx){
	if (this -> f_arr[idx].get_dest() == this -> f_arr[idx].get_curr_loc()){ //sees if flight wanting to take off has already taken off
		cout << "This flight is already at its final destination." << endl;
		return 1;
	}	
	return 2;	
}

//getter
string Airport::get_destination(int flight){
	return this-> f_arr[flight-1].get_dest();
}

//adds to counter for how many flights have this airport listed as their destination
void Airport:: listed_destination(int& count, string airport_name){	
	for (int f = 0; f < this->num_flights; f++){
		if (f_arr[f].get_dest() == airport_name){ // sees if each flights dest is this airport name
			count ++;
		}
	}
	return;
}

//prints stats of airport
void Airport:: print_stats(){
	cout << "--------------Airport Name: " << this -> name << "--------------" << endl;
	cout << "Number of Flights Currently: " << this -> num_flights << endl;
	cout << "Capacity: " << this -> cap << endl;	
	return;
}

//redoes text file
void Airport:: output_to_text(ofstream& fout){
	for (int f = 0; f < this-> num_flights; f++){
		fout << f_arr[f].get_flight_num() << " " << f_arr[f].get_curr_loc() << " " << f_arr[f].get_dest() << " " << f_arr[f].get_num_pilots() << " ";
		f_arr[f].pilots_to_file(fout);
		fout << endl;		
	}
}

//prints airport and all flights
void Airport::print_airport() {
	//cout << "in print airport" << endl;
	cout << "--------------Airport Name: " << this -> name << "--------------" << endl;
	cout << "Number of Flights Currently: " << this -> num_flights << endl;
	cout << "Capacity: " << this -> cap << endl;
	for (int h = 0; h < this -> num_flights; h++){ 
		cout << "Flight: " << h+1 << endl;
		this -> f_arr[h].print_flight(); //calls all flights to print their info
	}
	cout << endl;
	return; 
}

