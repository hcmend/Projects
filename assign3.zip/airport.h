#ifndef AIRPORT_H
#define AIRPORT_H 

#include <iostream>
#include <string>
#include <fstream>

#include "flight.h"

using namespace std;

class Airport
{
private:
	string name;		//airport name
	int num_flights;	//number of flights
	int cap;			//capacity
	Flight *f_arr;		//flight array

public:
	//airport only needs a default constructor and destructor because we are never copying an airport to another airport object. 
	Airport();
	~Airport();

	/*********************************************************************  
	** Function: get_name()
	** Description: this returns the name of the airport
	** Parameters:  none
	** Pre-Conditions: the airport has been declared and has a name
	** Post-Conditions:  none
	*********************************************************************/ 
	string get_name () const;

	/*********************************************************************  
	** Function: get_num_flights()
	** Description: this returns the amount of flights in the airport
	** Parameters:  none
	** Pre-Conditions: the airport has been declared and has a num_flights initialized
	** Post-Conditions:  none
	*********************************************************************/ 
	int get_num_flights () const;

	/*********************************************************************  
	** Function: get_cap()
	** Description: this returns the capacity of the airport
	** Parameters:  none
	** Pre-Conditions: the airport has been declared and has a capacity initialized
	** Post-Conditions:  none
	*********************************************************************/ 
	int get_cap () const;

	/*********************************************************************  
	** Function: populate_airport(ifstream)
	** Description: this returns the name of the airport
	** Parameters:  ifstream& - a file input that has already been declared and opened a file
	** Pre-Conditions: the airport has been declared but not initialzed. ifstream has been set up correctly
	** Post-Conditions:  uses file input to correctly initialize airport
	*********************************************************************/ 
	void populate_airport(ifstream& fin);

	/*********************************************************************  
	** Function: check_for_flight(string)
	** Description: this compares all flight numbers in airports to the string parameter
	** Parameters:  string: flight number inputted by user to be searched for
	** Pre-Conditions: user inputted string, airports and flights have been initialized correctly
	** Post-Conditions:  none
	*********************************************************************/ 
	int check_for_flight (string flight_search);

	/*********************************************************************  
	** Function: add_a_flight(Flight)
	** Description: this adds a flight that the user inputted all info of to the end of flight array in this airport
	** Parameters:  Flight: a flight object with all information from user
	** Pre-Conditions: flight object has been set up correctly, airport is not already at capacity and is set up
	** Post-Conditions:  flight was added to next open spot in array
	*********************************************************************/ 
	void add_a_flight(Flight& p);

	/*********************************************************************  
	** Function: add_a_complete_flight(Flight)
	** Description: this radds a flight that has just taken off from a different airport to the end of a flight array
	** Parameters:  Flight: the flight that took off
	** Pre-Conditions: corrent fligth has taken off and its destination is not at capacity
	** Post-Conditions:  flight was added to next open spot of its destination airport
	*********************************************************************/ 
	void add_a_complete_flight(Flight& p);
	
	/*********************************************************************  
	** Function: remove_a_flight(int)
	** Description: this rremoves a flight from a flight array either because it has taken off or because user said to get rid of it
	** Parameters:  idx: the index of flight in the flight array to remove
	** Pre-Conditions: flight array has been set up correctly and idx is correct
	** Post-Conditions:  flights in array after index have been shifted done an index correctly
	*********************************************************************/ 
	Flight remove_a_flight(int idx);

	/*********************************************************************  
	** Function: check_if_at_destination(int)
	** Description: this checks if a flight has already taken off and landed at its destination
	** Parameters:  idx: index of flight in flight array to check
	** Pre-Conditions: idx is correct, flight array has beeen set up right
	** Post-Conditions:  none
	*********************************************************************/ 
	int check_if_at_destination(int idx);

	/*********************************************************************  
	** Function: get_destination()
	** Description: this returns the destination of a specifc flight
	** Parameters: int: index of flight to find dest of
	** Pre-Conditions: flights were set up right
	** Post-Conditions: found its correct destination
	*********************************************************************/ 
	string get_destination(int flight);

	/*********************************************************************  
	** Function: listed_destination(int&, string)
	** Description: this finds how many flights have this airport listed as their destination
	** Parameters:  int&: reference to variable counting amount of flights
					string: destination airport to search for
	** Pre-Conditions: destinations of flights have been set up correctly
	** Post-Conditions:  found right number of flights
	*********************************************************************/ 
	void listed_destination(int&, string);

	/*********************************************************************  
	** Function: print_stats()
	** Description: this prints the name, flights at, capacity, and flights this airport as their destination of this airport
	** Parameters:  none
	** Pre-Conditions: the airport has been declared and inittialized correctly
	** Post-Conditions:  none
	*********************************************************************/ 
	void print_stats();

	/*********************************************************************  
	** Function: output_to_text()
	** Description: this updates the text file at the end of the program
	** Parameters:  ofstream: file output stream that has been declared and opened
	** Pre-Conditions: all arrays have been updated
	** Post-Conditions:  info was outputted to file correctly
	*********************************************************************/ 
	void output_to_text(ofstream& fout);

	/*********************************************************************  
	** Function: print_airport()
	** Description: this prints all the information of this airport and calls print_flight for every flight in its array
	** Parameters:  none
	** Pre-Conditions: all arrays have been set up right
	** Post-Conditions:  none
	*********************************************************************/ 
	void print_airport();	
	
};
#endif