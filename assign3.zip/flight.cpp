#include "flight.h"

using namespace std;

Flight::Flight() {
	
}

Flight :: Flight(string location, string flight_number, string destination, int size){
	//cout << "non-default constructor called" << endl;
	this -> flight_num = flight_number; 
	this -> curr_loc = location; 
	this -> dest = destination;
	this -> num_pilots = size;
	this -> pilots = new string [size]; 
}

Flight::~Flight(){
	//cout << "destructor called" << endl;
	if (this -> pilots != NULL){ 
		delete [] this-> pilots; //deletes pilot array within flight
		this -> pilots = NULL;
	}
}

Flight& Flight::operator=(const Flight& f){
	//cout << "AOO called" << endl;
	if (this == &f){ //exits if already equal
		return *this;
	}
	//sets flightnum, location, and destination, to those of f
	this -> flight_num = f.flight_num; 
	this -> curr_loc = f.curr_loc;
	this -> dest = f.dest;
	if (this->pilots != NULL){ 
		delete [] this -> pilots; //deletes pilot array if not already null		
	}	
	this -> num_pilots = f.num_pilots; //sets num_pilots to that of f
	this -> pilots = new string[this -> num_pilots];
	for (int i = 0; i < this -> num_pilots; i++){
		this->pilots[i] = f.pilots[i]; //fills pilots with pilot names from f
	}
	return *this;
}

Flight :: Flight (const Flight& f){	
	//cout << "CC Called" << endl;
	//sets all information to those of f so that they are identical
	this -> flight_num = f.flight_num; 
	this -> curr_loc = f.curr_loc;
	this -> dest = f.dest;
	this -> num_pilots = f.num_pilots;
	this -> pilots = new string [this-> num_pilots];
	for(int i = 0; i < this-> num_pilots; i++){
		this -> pilots[i] = f.pilots[i];
	}
}

void Flight::populate_flight(ifstream& fin) {
	//fills in all flight variables with info from file
	fin >> this -> flight_num;
	fin >> this -> curr_loc;
	fin >> this -> dest;
	fin >> this -> num_pilots;
	this -> pilots = new string [num_pilots];
	for (int p = 0; p < num_pilots; p++){
		fin >> pilots[p];
	}
	
	return;
}

//getters
string Flight :: get_flight_num () const {
	return this->flight_num;
}

string Flight :: get_dest () const {
	return this->dest;
}

int Flight :: get_num_pilots() const{
	return this-> num_pilots;
}

string Flight :: get_curr_loc () const {
	return this->curr_loc;
}

void Flight :: set_curr_loc(string new_location){
	this -> curr_loc = new_location;
	return;
}

void Flight::fill_pilots(){
	string pilot_name;
	for (int p = 0; p < this-> num_pilots; p++){
		cout << "Enter name for pilot " << p + 1 << ": ";
		cin >> pilot_name;
		this -> pilots[p] = pilot_name;
	}
	//cout << "done populating pilots";
	this -> print_flight(); 
}

void Flight::pilots_to_file(ofstream& fout){
	for (int p = 0; p < num_pilots; p++){
		fout << pilots[p] << " ";	
	}
	return;
}


void Flight::print_flight() {
	cout << "---------------------------------------" << endl;
	cout << "Flight Number: " << this-> flight_num << endl;
	cout << "Current Location: " << this -> curr_loc << endl;
	cout << "Destination: " << this -> dest << endl;
	cout << "Number of Pilots: " << this -> num_pilots << endl;
	for(int i = 0; i < num_pilots; i++){
		cout << "Pilot " << i+1 << ": " << this -> pilots[i] << endl;
	}
	cout << "---------------------------------------" << endl;
	return;
}




