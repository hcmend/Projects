#ifndef FLIGHT_H
#define FLIGHT_H 

#include <iostream>
#include <string>
#include <fstream>

using namespace std;

class Flight
{
private: 
	string flight_num;		//flight number
	string curr_loc;		//current airport
	string dest;			//destination 
	int num_pilots;			//number of pilots
	string* pilots;			//pilot array

public:
	Flight(); //default constructor
	Flight(string, string, string, int); // non-default constructor. needed for when user inputs all the information and we want to construct a flight with all of that
	//flight class needs big3 because we sometimes need to copy flight info into another flight or create a flight that has same info of existing flight
	~Flight(); // destructor
	Flight& operator=(const Flight&); // assignment operator overload	 
	Flight(const Flight&); // copy constructor

	/*********************************************************************  
	** Function: populate_flight(ifstream&)
	** Description: this sets up the flight and all its variables with information from file
	** Parameters:  ifstream&: file input that has been declared and opened 
	** Pre-Conditions: file stream is set up correctly and right file is open
	** Post-Conditions:  flight was populated right
	*********************************************************************/
	void populate_flight(ifstream&);

	/*********************************************************************  
	** Function: get_flight_num()
	** Description: this returns the flight num
	** Parameters:  none
	** Pre-Conditions: flight has been initialized
	** Post-Conditions:  none
	*********************************************************************/
	string get_flight_num () const;

	/*********************************************************************  
	** Function: get_dest()
	** Description: this returns the flight destination
	** Parameters:  none
	** Pre-Conditions: flight has been initialized
	** Post-Conditions:  none
	*********************************************************************/
	string get_dest () const ;

	/*********************************************************************  
	** Function: get_curr_loc()
	** Description: this returns the current airport flight is at
	** Parameters:  none
	** Pre-Conditions: flight has been initialized
	** Post-Conditions:  none
	*********************************************************************/
	string get_curr_loc () const ;

	/*********************************************************************  
	** Function: get_num_pilots()
	** Description: this returns the flight's number of pilots
	** Parameters:  none
	** Pre-Conditions: flight has been initialized
	** Post-Conditions:  none
	*********************************************************************/
	int get_num_pilots() const;

	/*********************************************************************  
	** Function: set_curr_loc(string)
	** Description: this sets the current location to the string passed in
	** Parameters:  string: name of airport the flight is to be set at
	** Pre-Conditions: flight has been initialized
	** Post-Conditions:  current location was updated correctly
	*********************************************************************/
	void set_curr_loc(string new_location);

	/*********************************************************************  
	** Function: fill_pilots()
	** Description: this fills in the pilot array with info from user when they choose option add a flight
	** Parameters:  none
	** Pre-Conditions: flight has been declared
	** Post-Conditions:  pilots were filled correctly
	*********************************************************************/
	void fill_pilots();	

	/*********************************************************************  
	** Function: pilots_to_file()
	** Description: this prints the pilot array to the file output at end of program
	** Parameters:  ofstream: file output stream that has been declared and opened
	** Pre-Conditions: flights and pilots are all correct
	** Post-Conditions:  info was printed correctly
	*********************************************************************/
	void pilots_to_file(ofstream& fout);

	/*********************************************************************  
	** Function: print_flight()
	** Description: this prints all member variables of flight to screen when user chooses option print all
	** Parameters:  none
	** Pre-Conditions: flight has been initialzed
	** Post-Conditions:  none
	*********************************************************************/
	void print_flight();	
	
};

#endif
