#include "manager.h"

using namespace std;


Manager::Manager(){
	//cout << "default constructor called";
	//blank because we will fill it in with info from user
}


Manager::~Manager() {
	//cout << "destructor called" << endl;
	if (this -> a_arr != NULL){
		delete [] this-> a_arr; //deletes airport array within manager
		this -> a_arr = NULL;
	}
}

//starts the chain of populating
void Manager::populate(ifstream& fin) {
	fin >> this->num_airports;
	this -> a_arr = new Airport [num_airports];
	for (int i = 0; i < num_airports; i++){
		a_arr[i].populate_airport(fin); //calls all airports to populate themselves and sends file to them
	}	
	return; 
}

//opens file input stream
int Manager::init(){
	ifstream fin; //creates file input stream
	//Error opening file?:	
    fin.open("airport.txt", ios::in); //opens airport.txt
    // Check if file is valid
    if(!fin.is_open()){
        cout << "Sorry, the file was not able to be opened." << endl;
        return 0;
	}
	Manager::populate(fin); //calls function that populates everything
	fin.close();
	return 1;
}

//gives user their options
void Manager::print_menu(){
	cout << endl;
	cout << "1. View all Airports & Flights info" << endl;
	cout << "2. Check flight info" << endl;
	cout << "3. Add a new flight" << endl;
	cout << "4. Cancel a flight" << endl;
	cout << "5. Take off a flight" << endl;
	cout << "6. Print airport stats" << endl;
	cout << "7. Quit" << endl;

	cout << "Your choice: ";
}

//takes option from user
int Manager::get_menu_choice() {
	int choice = 0;
	do {
		Manager::print_menu(); //prints user options
		cin >> choice; //gets their choice

		//error handling!
		if (!(choice > 0 && choice < 8)){
			cout << "I am sorry. That was not a valid input." << endl;
		}
	} while (!(choice > 0 && choice < 8));
	return choice;
}

//prints all airports and flights
void Manager::print_all(){
	//cout << "calling airports to print" << endl;
	for (int i = 0; i < this -> num_airports; i++){
		this -> a_arr[i].print_airport(); //calls all airports to print themselves
	}
	return; 
}

//gets flight number user wants to search for and checks for it
void Manager::check_flight_control() {
	string flight_search;
	cout << "Please enter the flight  number you would like to search for: ";
	cin >> flight_search; //gets flight number user wants to look for
	bool found = false;
	for (int a = 0; a < num_airports; a++){
		if (a_arr[a].check_for_flight(flight_search) == 1){ //has all airports see if they have that flight in their array
			found = true; 
		}
	}
	if (!found){
		cout << "I am sorry, that flight could not be found " << endl;
	}	 
	return; 
}

//adds a flight to specific airport
void Manager::add_flight_control() {
	cout << endl;
	for (int i = 0; i < num_airports; i++){
		cout << i + 1 << ": Airport " << a_arr[i].get_name() << endl; //prints airport options to add flight too
	}
	int airport; 
	do{
		cout << "Please choose an airport: ";
		cin >> airport;
		if (airport <= 0 || airport > num_airports){ 
			cout << "Sorry, that is not a valid airport." << endl; //error handles 
		}
		if (a_arr[airport - 1].get_num_flights() == a_arr[airport-1].get_cap()){ //makes sure that airport is not already at capacity
			cout << "Sorry, no more flights can be added to that airport. " << endl;
			return;
		}
	} while (!(airport > 0 && airport <= num_airports));
	
	//gets user to enter all information about the flight
	string flight_number;	
	cout << "Flight number: " ;
	cin >> flight_number;
	string destination;
	cout << "Destination: " ;   
	cin >> destination;	
	int num_pilots;
	do{		
		cout << "Number of pilots: " ;
		cin >> num_pilots;
	}while(!(num_pilots > 0));
	Flight f_new(a_arr[airport - 1].get_name(), flight_number, destination, num_pilots); //creates flight object with all that information
	a_arr[airport-1].add_a_flight(f_new); //calls that airport to add flight to themselves
	return;
}

//cancels specific flight
void Manager::cancel_flight_control() {
	for (int i = 0; i < num_airports; i++){
		cout << i + 1 << ": Airport " << a_arr[i].get_name() << endl; //prints to user airport options to cancel flight from
	}
	int airport;
	do{
		cout << "Please choose an airport: ";
		cin >> airport;
		if (airport <= 0 || airport > num_airports){
			cout << "Sorry, that is not a valid airport." << endl;
		}		
	} while (!(airport > 0 && airport <= num_airports));
	a_arr[airport-1].print_airport(); //prints flight options to cancel
	int flight;
	do {
		cout << "Choose a flight: ";
		cin >> flight;
		if (flight <= 0 || flight > a_arr[airport-1].get_num_flights()){
			cout << "Sorry, that is not a valid flight." << endl;
		}
	} while (!(flight > 0 && flight <= a_arr[airport-1].get_num_flights()));
	Flight f = a_arr[airport-1].remove_a_flight(flight-1); //calls that airport to remove that flight from their array
	cout << "The following flight has been removed: " << endl;
	f.print_flight(); //prints flight that has been cancelled
	return;
}

//takes a specific flight off moving it to it's destination
void Manager::take_off_control() {
	for (int i = 0; i < num_airports; i++){
		cout << i + 1 << ": Airport " << a_arr[i].get_name() << endl; //prints airports user can take off flight from
	}
	int airport;
	do{
		cout << "Please choose an airport: ";
		cin >> airport;
		if (airport <= 0 || airport > num_airports){
			cout << "Sorry, that is not a valid airport." << endl;
		}		
	} while (!(airport > 0 && airport <= num_airports));
	a_arr[airport-1].print_airport(); //prints all flights in that airport user can take off
	int flight;
	do {
		cout << "Choose a flight: ";
		cin >> flight;
		if (flight <= 0 || flight > a_arr[airport-1].get_num_flights()){
			cout << "Sorry, that is not a valid flight." << endl;
		}
	} while (!(flight > 0 && flight <= a_arr[airport-1].get_num_flights()));
	if (a_arr[airport-1].check_if_at_destination(flight-1) == 1){ //sees if that flight is already at dest
		return;
	}
	int index_to_add_to;
	for (int a = 0; a < num_airports; a++){
		if (a_arr[a].get_name() == a_arr[airport-1].get_destination(flight)){
			index_to_add_to = a; //matches destination of that flight to name of an airport		
			if(a_arr[a].get_num_flights() == a_arr[a].get_cap()){ //checks if that airport is full
				cout << "I am sorry. That flight's destination airport is at capacity. It will not be able to take off." << endl;
				return;
			}	
		}
	}
	Flight f = a_arr[airport-1].remove_a_flight(flight-1); //removes flight from current location
	a_arr[index_to_add_to].add_a_complete_flight(f); //adds it to new destination airport
	cout << "This flight has taken off: " << endl;
	f.print_flight();
	return; 
}

//prints airport statistics;
void Manager::stats_control() {
	for (int a = 0; a < num_airports; a++){
		int count = 0;
		a_arr[a].print_stats(); //prints information about airport that is already contained in it
		//Manager::get_destination_counts();		
		for (int b = 0; b < num_airports; b++){			
			a_arr[b].listed_destination(count, a_arr[a].get_name()); //find how many flights have that airport as their destination
		}		
		cout << "Listed as destination: " << count << endl; 
		cout << endl;		
	}	
	return; 
}

//refills the text file with the new information after user has used program
void Manager::update_text_file(){
	ofstream fout; //creates file output
	fout.open("airport.txt"); //opens same file we got info from
	fout << this->num_airports << endl;	
	for (int a = 0; a < num_airports; a++){
		fout << a_arr[a].get_name() << " " << a_arr[a].get_num_flights() << " " << a_arr[a].get_cap() << endl; //prints airport info to that file
		a_arr[a].output_to_text(fout); //calls those airports to print their flight info to that file
	}
	fout.close();
}

//runs everything
void Manager::run() {
	cout << endl;
	cout << "Welcome to Flight Manager!!" << endl;
	if (Manager::init() != 1){
		return;
	}
	int choice = -1;
	while (choice != 7){
		choice = Manager::get_menu_choice();

		//print all
		if (choice == 1){
			Manager::print_all();
		}
		//flight info
		else if (choice == 2){
			Manager::check_flight_control();
		}
		//add a new flight
		else if (choice == 3) {
			Manager::add_flight_control();
		}
		//cancel a flight
		else if (choice == 4) {
			Manager::cancel_flight_control();
		}
		//take off a flight
		if (choice == 5){
			Manager::take_off_control();
		}
		//airport stats
		else if (choice == 6) {
			Manager::stats_control();
		}
	}
	Manager :: update_text_file();
	cout << "Bye!" << endl << endl;		
	return;
}